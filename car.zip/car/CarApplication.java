package com.example.car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import dao.entities.Car;
import service.CarService;
import org.springframework.stereotype.Service;
import java.util.List;



@SpringBootApplication
public class CarApplication implements CommandLineRunner {

    @Autowired
    private CarService carService;

    public static void main(String[] args) {
        SpringApplication.run(CarApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        carService.addCar(new Car(null, "Tessla", "Rouge", 630000, "B47845"));
        carService.addCar(new Car(null, "BMW", "Noir", 150000, "BG1478"));
        carService.addCar(new Car(null, "Renault Clio", "Blanc", 120000, "FB4789"));
        carService.addCar(new Car(null, "Mercedes", "Gris", 450000, "A47851"));
        carService.addCar(new Car(null, "Dacia", "Gris", 110000, "A74741"));

        System.out.println("Cars  :");
        carService.getAllCars().forEach(System.out::println);
    }
}